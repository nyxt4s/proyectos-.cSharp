﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prueba
{
    class Validacion
    {
        public bool val_login(string us, string pas)
        {
            if (us == string.Empty && pas == string.Empty)
            {
                return true;
            }
            else
            {
                return true;
            }
        }
    }
}
