﻿namespace prueba
{
    partial class Stock
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.iDAROSDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nOMBREDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dESCRIPCIÓNDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pRECIODataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sTOCKDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.aROSBindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.bdElCofreDelBordadoDataSet14 = new prueba.BdElCofreDelBordadoDataSet14();
            this.aROSBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.bdElCofreDelBordadoDataSet11 = new prueba.BdElCofreDelBordadoDataSet11();
            this.aROSBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.bdElCofreDelBordadoDataSet6 = new prueba.BdElCofreDelBordadoDataSet6();
            this.bdElCofreDelBordadoDataSet3 = new prueba.BdElCofreDelBordadoDataSet3();
            this.aROSBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.aROSTableAdapter = new prueba.BdElCofreDelBordadoDataSet3TableAdapters.AROSTableAdapter();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.iDBASTIDORDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nOMBREDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dESCRIPCIÓNDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pRECIODataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bASTIDORESBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.bdElCofreDelBordadoDataSet10 = new prueba.BdElCofreDelBordadoDataSet10();
            this.bASTIDORESBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.bdElCofreDelBordadoDataSet4 = new prueba.BdElCofreDelBordadoDataSet4();
            this.bASTIDORESTableAdapter = new prueba.BdElCofreDelBordadoDataSet4TableAdapters.BASTIDORESTableAdapter();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.iDACCESORIOSDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nOMBREDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tIPODataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dESCRIPCIONDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pRECIODataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.aCCESORIOSBindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.bdElCofreDelBordadoDataSet9 = new prueba.BdElCofreDelBordadoDataSet9();
            this.aCCESORIOSBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.bdElCofreDelBordadoDataSet8 = new prueba.BdElCofreDelBordadoDataSet8();
            this.aCCESORIOSBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.bdElCofreDelBordadoDataSet5 = new prueba.BdElCofreDelBordadoDataSet5();
            this.aCCESORIOSTableAdapter = new prueba.BdElCofreDelBordadoDataSet5TableAdapters.ACCESORIOSTableAdapter();
            this.label10 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.txtBuscar = new System.Windows.Forms.TextBox();
            this.aROSTableAdapter1 = new prueba.BdElCofreDelBordadoDataSet6TableAdapters.AROSTableAdapter();
            this.bdElCofreDelBordadoDataSet7 = new prueba.BdElCofreDelBordadoDataSet7();
            this.aCCESORIOSBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.aCCESORIOSTableAdapter1 = new prueba.BdElCofreDelBordadoDataSet7TableAdapters.ACCESORIOSTableAdapter();
            this.aCCESORIOSTableAdapter2 = new prueba.BdElCofreDelBordadoDataSet8TableAdapters.ACCESORIOSTableAdapter();
            this.aCCESORIOSTableAdapter3 = new prueba.BdElCofreDelBordadoDataSet9TableAdapters.ACCESORIOSTableAdapter();
            this.bASTIDORESTableAdapter1 = new prueba.BdElCofreDelBordadoDataSet10TableAdapters.BASTIDORESTableAdapter();
            this.aROSTableAdapter2 = new prueba.BdElCofreDelBordadoDataSet11TableAdapters.AROSTableAdapter();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btnRellenar = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.txtTipo = new System.Windows.Forms.TextBox();
            this.txtPrecio = new System.Windows.Forms.TextBox();
            this.txtStock = new System.Windows.Forms.TextBox();
            this.txtDescripcion = new System.Windows.Forms.TextBox();
            this.txtNombre = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label9 = new System.Windows.Forms.Label();
            this.btnEliminar = new System.Windows.Forms.Button();
            this.txtWea = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.aROSTableAdapter3 = new prueba.BdElCofreDelBordadoDataSet14TableAdapters.AROSTableAdapter();
            this.label15 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.aROSBindingSource3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bdElCofreDelBordadoDataSet14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.aROSBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bdElCofreDelBordadoDataSet11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.aROSBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bdElCofreDelBordadoDataSet6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bdElCofreDelBordadoDataSet3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.aROSBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bASTIDORESBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bdElCofreDelBordadoDataSet10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bASTIDORESBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bdElCofreDelBordadoDataSet4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.aCCESORIOSBindingSource3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bdElCofreDelBordadoDataSet9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.aCCESORIOSBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bdElCofreDelBordadoDataSet8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.aCCESORIOSBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bdElCofreDelBordadoDataSet5)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bdElCofreDelBordadoDataSet7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.aCCESORIOSBindingSource1)).BeginInit();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToResizeColumns = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(66)))), ((int)(((byte)(91)))));
            this.dataGridView1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView1.ColumnHeadersHeight = 25;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDAROSDataGridViewTextBoxColumn,
            this.nOMBREDataGridViewTextBoxColumn1,
            this.dESCRIPCIÓNDataGridViewTextBoxColumn1,
            this.pRECIODataGridViewTextBoxColumn1,
            this.sTOCKDataGridViewTextBoxColumn1});
            this.dataGridView1.DataSource = this.aROSBindingSource3;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView1.EnableHeadersVisualStyles = false;
            this.dataGridView1.GridColor = System.Drawing.Color.SteelBlue;
            this.dataGridView1.Location = new System.Drawing.Point(25, 80);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersVisible = false;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(66)))), ((int)(((byte)(91)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.SteelBlue;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.White;
            this.dataGridView1.RowsDefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridView1.Size = new System.Drawing.Size(783, 185);
            this.dataGridView1.TabIndex = 12;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            this.dataGridView1.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dataGridView1_CellFormatting);
            this.dataGridView1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.dataGridView1_KeyPress);
            // 
            // iDAROSDataGridViewTextBoxColumn
            // 
            this.iDAROSDataGridViewTextBoxColumn.DataPropertyName = "ID_AROS";
            this.iDAROSDataGridViewTextBoxColumn.HeaderText = "ID_AROS";
            this.iDAROSDataGridViewTextBoxColumn.Name = "iDAROSDataGridViewTextBoxColumn";
            this.iDAROSDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // nOMBREDataGridViewTextBoxColumn1
            // 
            this.nOMBREDataGridViewTextBoxColumn1.DataPropertyName = "NOMBRE";
            this.nOMBREDataGridViewTextBoxColumn1.HeaderText = "NOMBRE";
            this.nOMBREDataGridViewTextBoxColumn1.Name = "nOMBREDataGridViewTextBoxColumn1";
            this.nOMBREDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // dESCRIPCIÓNDataGridViewTextBoxColumn1
            // 
            this.dESCRIPCIÓNDataGridViewTextBoxColumn1.DataPropertyName = "DESCRIPCIÓN";
            this.dESCRIPCIÓNDataGridViewTextBoxColumn1.HeaderText = "DESCRIPCIÓN";
            this.dESCRIPCIÓNDataGridViewTextBoxColumn1.Name = "dESCRIPCIÓNDataGridViewTextBoxColumn1";
            this.dESCRIPCIÓNDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // pRECIODataGridViewTextBoxColumn1
            // 
            this.pRECIODataGridViewTextBoxColumn1.DataPropertyName = "PRECIO";
            this.pRECIODataGridViewTextBoxColumn1.HeaderText = "PRECIO";
            this.pRECIODataGridViewTextBoxColumn1.Name = "pRECIODataGridViewTextBoxColumn1";
            this.pRECIODataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // sTOCKDataGridViewTextBoxColumn1
            // 
            this.sTOCKDataGridViewTextBoxColumn1.DataPropertyName = "STOCK";
            this.sTOCKDataGridViewTextBoxColumn1.HeaderText = "STOCK";
            this.sTOCKDataGridViewTextBoxColumn1.Name = "sTOCKDataGridViewTextBoxColumn1";
            this.sTOCKDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // aROSBindingSource3
            // 
            this.aROSBindingSource3.DataMember = "AROS";
            this.aROSBindingSource3.DataSource = this.bdElCofreDelBordadoDataSet14;
            // 
            // bdElCofreDelBordadoDataSet14
            // 
            this.bdElCofreDelBordadoDataSet14.DataSetName = "BdElCofreDelBordadoDataSet14";
            this.bdElCofreDelBordadoDataSet14.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // aROSBindingSource2
            // 
            this.aROSBindingSource2.DataMember = "AROS";
            this.aROSBindingSource2.DataSource = this.bdElCofreDelBordadoDataSet11;
            // 
            // bdElCofreDelBordadoDataSet11
            // 
            this.bdElCofreDelBordadoDataSet11.DataSetName = "BdElCofreDelBordadoDataSet11";
            this.bdElCofreDelBordadoDataSet11.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // aROSBindingSource1
            // 
            this.aROSBindingSource1.DataMember = "AROS";
            this.aROSBindingSource1.DataSource = this.bdElCofreDelBordadoDataSet6;
            // 
            // bdElCofreDelBordadoDataSet6
            // 
            this.bdElCofreDelBordadoDataSet6.DataSetName = "BdElCofreDelBordadoDataSet6";
            this.bdElCofreDelBordadoDataSet6.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // bdElCofreDelBordadoDataSet3
            // 
            this.bdElCofreDelBordadoDataSet3.DataSetName = "BdElCofreDelBordadoDataSet3";
            this.bdElCofreDelBordadoDataSet3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // aROSBindingSource
            // 
            this.aROSBindingSource.DataMember = "AROS";
            this.aROSBindingSource.DataSource = this.bdElCofreDelBordadoDataSet3;
            // 
            // aROSTableAdapter
            // 
            this.aROSTableAdapter.ClearBeforeFill = true;
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToAddRows = false;
            this.dataGridView2.AllowUserToDeleteRows = false;
            this.dataGridView2.AllowUserToResizeColumns = false;
            this.dataGridView2.AllowUserToResizeRows = false;
            this.dataGridView2.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.dataGridView2.AutoGenerateColumns = false;
            this.dataGridView2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView2.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(66)))), ((int)(((byte)(91)))));
            this.dataGridView2.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridView2.ColumnHeadersHeight = 25;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDBASTIDORDataGridViewTextBoxColumn,
            this.nOMBREDataGridViewTextBoxColumn,
            this.dESCRIPCIÓNDataGridViewTextBoxColumn,
            this.pRECIODataGridViewTextBoxColumn,
            this.dataGridViewTextBoxColumn2});
            this.dataGridView2.DataSource = this.bASTIDORESBindingSource1;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView2.DefaultCellStyle = dataGridViewCellStyle5;
            this.dataGridView2.EnableHeadersVisualStyles = false;
            this.dataGridView2.GridColor = System.Drawing.Color.SteelBlue;
            this.dataGridView2.Location = new System.Drawing.Point(22, 296);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            this.dataGridView2.RowHeadersVisible = false;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(66)))), ((int)(((byte)(91)))));
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.SteelBlue;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.Color.White;
            this.dataGridView2.RowsDefaultCellStyle = dataGridViewCellStyle6;
            this.dataGridView2.Size = new System.Drawing.Size(786, 185);
            this.dataGridView2.TabIndex = 13;
            this.dataGridView2.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellClick);
            this.dataGridView2.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellContentClick);
            this.dataGridView2.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dataGridView2_CellFormatting);
            // 
            // iDBASTIDORDataGridViewTextBoxColumn
            // 
            this.iDBASTIDORDataGridViewTextBoxColumn.DataPropertyName = "ID_BASTIDOR";
            this.iDBASTIDORDataGridViewTextBoxColumn.HeaderText = "ID_BASTIDOR";
            this.iDBASTIDORDataGridViewTextBoxColumn.Name = "iDBASTIDORDataGridViewTextBoxColumn";
            this.iDBASTIDORDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // nOMBREDataGridViewTextBoxColumn
            // 
            this.nOMBREDataGridViewTextBoxColumn.DataPropertyName = "NOMBRE";
            this.nOMBREDataGridViewTextBoxColumn.HeaderText = "NOMBRE";
            this.nOMBREDataGridViewTextBoxColumn.Name = "nOMBREDataGridViewTextBoxColumn";
            this.nOMBREDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // dESCRIPCIÓNDataGridViewTextBoxColumn
            // 
            this.dESCRIPCIÓNDataGridViewTextBoxColumn.DataPropertyName = "DESCRIPCIÓN";
            this.dESCRIPCIÓNDataGridViewTextBoxColumn.HeaderText = "DESCRIPCIÓN";
            this.dESCRIPCIÓNDataGridViewTextBoxColumn.Name = "dESCRIPCIÓNDataGridViewTextBoxColumn";
            this.dESCRIPCIÓNDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // pRECIODataGridViewTextBoxColumn
            // 
            this.pRECIODataGridViewTextBoxColumn.DataPropertyName = "PRECIO";
            this.pRECIODataGridViewTextBoxColumn.HeaderText = "PRECIO";
            this.pRECIODataGridViewTextBoxColumn.Name = "pRECIODataGridViewTextBoxColumn";
            this.pRECIODataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "STOCK";
            this.dataGridViewTextBoxColumn2.HeaderText = "STOCK";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // bASTIDORESBindingSource1
            // 
            this.bASTIDORESBindingSource1.DataMember = "BASTIDORES";
            this.bASTIDORESBindingSource1.DataSource = this.bdElCofreDelBordadoDataSet10;
            // 
            // bdElCofreDelBordadoDataSet10
            // 
            this.bdElCofreDelBordadoDataSet10.DataSetName = "BdElCofreDelBordadoDataSet10";
            this.bdElCofreDelBordadoDataSet10.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // bASTIDORESBindingSource
            // 
            this.bASTIDORESBindingSource.DataMember = "BASTIDORES";
            this.bASTIDORESBindingSource.DataSource = this.bdElCofreDelBordadoDataSet4;
            // 
            // bdElCofreDelBordadoDataSet4
            // 
            this.bdElCofreDelBordadoDataSet4.DataSetName = "BdElCofreDelBordadoDataSet4";
            this.bdElCofreDelBordadoDataSet4.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // bASTIDORESTableAdapter
            // 
            this.bASTIDORESTableAdapter.ClearBeforeFill = true;
            // 
            // dataGridView3
            // 
            this.dataGridView3.AllowUserToAddRows = false;
            this.dataGridView3.AllowUserToDeleteRows = false;
            this.dataGridView3.AllowUserToResizeColumns = false;
            this.dataGridView3.AllowUserToResizeRows = false;
            this.dataGridView3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.dataGridView3.AutoGenerateColumns = false;
            this.dataGridView3.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView3.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(66)))), ((int)(((byte)(91)))));
            this.dataGridView3.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView3.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.dataGridView3.ColumnHeadersHeight = 25;
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dataGridView3.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDACCESORIOSDataGridViewTextBoxColumn,
            this.nOMBREDataGridViewTextBoxColumn2,
            this.tIPODataGridViewTextBoxColumn,
            this.dESCRIPCIONDataGridViewTextBoxColumn,
            this.pRECIODataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn1});
            this.dataGridView3.DataSource = this.aCCESORIOSBindingSource3;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView3.DefaultCellStyle = dataGridViewCellStyle8;
            this.dataGridView3.EnableHeadersVisualStyles = false;
            this.dataGridView3.GridColor = System.Drawing.Color.SteelBlue;
            this.dataGridView3.Location = new System.Drawing.Point(22, 517);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.ReadOnly = true;
            this.dataGridView3.RowHeadersVisible = false;
            dataGridViewCellStyle9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(66)))), ((int)(((byte)(91)))));
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle9.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.Color.SteelBlue;
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.Color.White;
            this.dataGridView3.RowsDefaultCellStyle = dataGridViewCellStyle9;
            this.dataGridView3.Size = new System.Drawing.Size(786, 185);
            this.dataGridView3.TabIndex = 14;
            this.dataGridView3.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView3_CellClick);
            this.dataGridView3.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView3_CellContentClick);
            this.dataGridView3.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dataGridView3_CellFormatting);
            // 
            // iDACCESORIOSDataGridViewTextBoxColumn
            // 
            this.iDACCESORIOSDataGridViewTextBoxColumn.DataPropertyName = "ID_ACCESORIOS";
            this.iDACCESORIOSDataGridViewTextBoxColumn.HeaderText = "ID_ACCESORIOS";
            this.iDACCESORIOSDataGridViewTextBoxColumn.Name = "iDACCESORIOSDataGridViewTextBoxColumn";
            this.iDACCESORIOSDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // nOMBREDataGridViewTextBoxColumn2
            // 
            this.nOMBREDataGridViewTextBoxColumn2.DataPropertyName = "NOMBRE";
            this.nOMBREDataGridViewTextBoxColumn2.HeaderText = "NOMBRE";
            this.nOMBREDataGridViewTextBoxColumn2.Name = "nOMBREDataGridViewTextBoxColumn2";
            this.nOMBREDataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // tIPODataGridViewTextBoxColumn
            // 
            this.tIPODataGridViewTextBoxColumn.DataPropertyName = "TIPO";
            this.tIPODataGridViewTextBoxColumn.HeaderText = "TIPO";
            this.tIPODataGridViewTextBoxColumn.Name = "tIPODataGridViewTextBoxColumn";
            this.tIPODataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // dESCRIPCIONDataGridViewTextBoxColumn
            // 
            this.dESCRIPCIONDataGridViewTextBoxColumn.DataPropertyName = "DESCRIPCION";
            this.dESCRIPCIONDataGridViewTextBoxColumn.HeaderText = "DESCRIPCION";
            this.dESCRIPCIONDataGridViewTextBoxColumn.Name = "dESCRIPCIONDataGridViewTextBoxColumn";
            this.dESCRIPCIONDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // pRECIODataGridViewTextBoxColumn2
            // 
            this.pRECIODataGridViewTextBoxColumn2.DataPropertyName = "PRECIO";
            this.pRECIODataGridViewTextBoxColumn2.HeaderText = "PRECIO";
            this.pRECIODataGridViewTextBoxColumn2.Name = "pRECIODataGridViewTextBoxColumn2";
            this.pRECIODataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "STOCK";
            this.dataGridViewTextBoxColumn1.HeaderText = "STOCK";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // aCCESORIOSBindingSource3
            // 
            this.aCCESORIOSBindingSource3.DataMember = "ACCESORIOS";
            this.aCCESORIOSBindingSource3.DataSource = this.bdElCofreDelBordadoDataSet9;
            // 
            // bdElCofreDelBordadoDataSet9
            // 
            this.bdElCofreDelBordadoDataSet9.DataSetName = "BdElCofreDelBordadoDataSet9";
            this.bdElCofreDelBordadoDataSet9.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // aCCESORIOSBindingSource2
            // 
            this.aCCESORIOSBindingSource2.DataMember = "ACCESORIOS";
            this.aCCESORIOSBindingSource2.DataSource = this.bdElCofreDelBordadoDataSet8;
            // 
            // bdElCofreDelBordadoDataSet8
            // 
            this.bdElCofreDelBordadoDataSet8.DataSetName = "BdElCofreDelBordadoDataSet8";
            this.bdElCofreDelBordadoDataSet8.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // aCCESORIOSBindingSource
            // 
            this.aCCESORIOSBindingSource.DataMember = "ACCESORIOS";
            this.aCCESORIOSBindingSource.DataSource = this.bdElCofreDelBordadoDataSet5;
            // 
            // bdElCofreDelBordadoDataSet5
            // 
            this.bdElCofreDelBordadoDataSet5.DataSetName = "BdElCofreDelBordadoDataSet5";
            this.bdElCofreDelBordadoDataSet5.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // aCCESORIOSTableAdapter
            // 
            this.aCCESORIOSTableAdapter.ClearBeforeFill = true;
            // 
            // label10
            // 
            this.label10.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(849, 517);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(149, 16);
            this.label10.TabIndex = 48;
            this.label10.Text = "BUSCAR POR NOMBRE";
            // 
            // panel2
            // 
            this.panel2.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.panel2.BackColor = System.Drawing.Color.Transparent;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.txtBuscar);
            this.panel2.Location = new System.Drawing.Point(852, 537);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(257, 147);
            this.panel2.TabIndex = 47;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(37, 11);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(190, 16);
            this.label8.TabIndex = 41;
            this.label8.Text = "Buscar nombre del material";
            // 
            // txtBuscar
            // 
            this.txtBuscar.Location = new System.Drawing.Point(70, 68);
            this.txtBuscar.Name = "txtBuscar";
            this.txtBuscar.Size = new System.Drawing.Size(128, 22);
            this.txtBuscar.TabIndex = 9;
            this.txtBuscar.TextChanged += new System.EventHandler(this.txtBuscar_TextChanged);
            // 
            // aROSTableAdapter1
            // 
            this.aROSTableAdapter1.ClearBeforeFill = true;
            // 
            // bdElCofreDelBordadoDataSet7
            // 
            this.bdElCofreDelBordadoDataSet7.DataSetName = "BdElCofreDelBordadoDataSet7";
            this.bdElCofreDelBordadoDataSet7.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // aCCESORIOSBindingSource1
            // 
            this.aCCESORIOSBindingSource1.DataMember = "ACCESORIOS";
            this.aCCESORIOSBindingSource1.DataSource = this.bdElCofreDelBordadoDataSet7;
            // 
            // aCCESORIOSTableAdapter1
            // 
            this.aCCESORIOSTableAdapter1.ClearBeforeFill = true;
            // 
            // aCCESORIOSTableAdapter2
            // 
            this.aCCESORIOSTableAdapter2.ClearBeforeFill = true;
            // 
            // aCCESORIOSTableAdapter3
            // 
            this.aCCESORIOSTableAdapter3.ClearBeforeFill = true;
            // 
            // bASTIDORESTableAdapter1
            // 
            this.bASTIDORESTableAdapter1.ClearBeforeFill = true;
            // 
            // aROSTableAdapter2
            // 
            this.aROSTableAdapter2.ClearBeforeFill = true;
            // 
            // panel3
            // 
            this.panel3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel3.BackColor = System.Drawing.Color.Transparent;
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.btnRellenar);
            this.panel3.Controls.Add(this.button2);
            this.panel3.Controls.Add(this.label1);
            this.panel3.Controls.Add(this.comboBox1);
            this.panel3.Controls.Add(this.label7);
            this.panel3.Controls.Add(this.label6);
            this.panel3.Controls.Add(this.label5);
            this.panel3.Controls.Add(this.label4);
            this.panel3.Controls.Add(this.label3);
            this.panel3.Controls.Add(this.button1);
            this.panel3.Controls.Add(this.txtTipo);
            this.panel3.Controls.Add(this.txtPrecio);
            this.panel3.Controls.Add(this.txtStock);
            this.panel3.Controls.Add(this.txtDescripcion);
            this.panel3.Controls.Add(this.txtNombre);
            this.panel3.Location = new System.Drawing.Point(852, 84);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(571, 373);
            this.panel3.TabIndex = 51;
            this.panel3.Paint += new System.Windows.Forms.PaintEventHandler(this.panel3_Paint);
            // 
            // btnRellenar
            // 
            this.btnRellenar.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.btnRellenar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(76)))), ((int)(((byte)(102)))));
            this.btnRellenar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(80)))), ((int)(((byte)(200)))));
            this.btnRellenar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRellenar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRellenar.ForeColor = System.Drawing.Color.White;
            this.btnRellenar.Location = new System.Drawing.Point(40, 324);
            this.btnRellenar.Name = "btnRellenar";
            this.btnRellenar.Size = new System.Drawing.Size(116, 29);
            this.btnRellenar.TabIndex = 51;
            this.btnRellenar.Text = "Rellenar";
            this.btnRellenar.UseVisualStyleBackColor = false;
            this.btnRellenar.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(76)))), ((int)(((byte)(102)))));
            this.button2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(80)))), ((int)(((byte)(200)))));
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(234, 324);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(116, 29);
            this.button2.TabIndex = 7;
            this.button2.Text = "Modificar";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(103, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(457, 16);
            this.label1.TabIndex = 50;
            this.label1.Text = "Puedes ingresar o seleccionar la tabla si deseas modifcar o agregar";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(212, 44);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(160, 24);
            this.comboBox1.TabIndex = 1;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            this.comboBox1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.comboBox1_KeyPress);
            // 
            // label7
            // 
            this.label7.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(154, 286);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(43, 16);
            this.label7.TabIndex = 11;
            this.label7.Text = "Stock";
            // 
            // label6
            // 
            this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(158, 134);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(39, 16);
            this.label6.TabIndex = 10;
            this.label6.Text = "Tipo ";
            // 
            // label5
            // 
            this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(149, 236);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(48, 16);
            this.label5.TabIndex = 9;
            this.label5.Text = "Precio";
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(112, 185);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(85, 16);
            this.label4.TabIndex = 8;
            this.label4.Text = "Descripcion";
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(137, 87);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(60, 16);
            this.label3.TabIndex = 7;
            this.label3.Text = "Nombre";
            // 
            // button1
            // 
            this.button1.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(76)))), ((int)(((byte)(102)))));
            this.button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(80)))), ((int)(((byte)(200)))));
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(420, 324);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(116, 29);
            this.button1.TabIndex = 8;
            this.button1.Text = "Agregar";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // txtTipo
            // 
            this.txtTipo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.txtTipo.Location = new System.Drawing.Point(212, 131);
            this.txtTipo.Name = "txtTipo";
            this.txtTipo.Size = new System.Drawing.Size(160, 22);
            this.txtTipo.TabIndex = 3;
            // 
            // txtPrecio
            // 
            this.txtPrecio.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.txtPrecio.Location = new System.Drawing.Point(212, 233);
            this.txtPrecio.Name = "txtPrecio";
            this.txtPrecio.Size = new System.Drawing.Size(160, 22);
            this.txtPrecio.TabIndex = 5;
            this.txtPrecio.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPrecio_KeyPress);
            // 
            // txtStock
            // 
            this.txtStock.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.txtStock.Location = new System.Drawing.Point(212, 283);
            this.txtStock.Name = "txtStock";
            this.txtStock.Size = new System.Drawing.Size(160, 22);
            this.txtStock.TabIndex = 6;
            this.txtStock.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtStock_KeyPress);
            // 
            // txtDescripcion
            // 
            this.txtDescripcion.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.txtDescripcion.Location = new System.Drawing.Point(212, 182);
            this.txtDescripcion.Name = "txtDescripcion";
            this.txtDescripcion.Size = new System.Drawing.Size(160, 22);
            this.txtDescripcion.TabIndex = 4;
            // 
            // txtNombre
            // 
            this.txtNombre.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.txtNombre.Location = new System.Drawing.Point(212, 84);
            this.txtNombre.Name = "txtNombre";
            this.txtNombre.Size = new System.Drawing.Size(160, 22);
            this.txtNombre.TabIndex = 2;
            // 
            // label11
            // 
            this.label11.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(1154, 517);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(139, 16);
            this.label11.TabIndex = 49;
            this.label11.Text = "ELIMINAR ELEMENTO";
            // 
            // panel4
            // 
            this.panel4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.panel4.BackColor = System.Drawing.Color.Transparent;
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Controls.Add(this.label9);
            this.panel4.Controls.Add(this.btnEliminar);
            this.panel4.Controls.Add(this.txtWea);
            this.panel4.Location = new System.Drawing.Point(1157, 539);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(266, 144);
            this.panel4.TabIndex = 48;
            this.panel4.Paint += new System.Windows.Forms.PaintEventHandler(this.panel4_Paint);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(79, 9);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(111, 16);
            this.label9.TabIndex = 43;
            this.label9.Text = "Borrar Elemento";
            // 
            // btnEliminar
            // 
            this.btnEliminar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(76)))), ((int)(((byte)(102)))));
            this.btnEliminar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(80)))), ((int)(((byte)(200)))));
            this.btnEliminar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEliminar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEliminar.ForeColor = System.Drawing.Color.White;
            this.btnEliminar.Location = new System.Drawing.Point(70, 64);
            this.btnEliminar.Name = "btnEliminar";
            this.btnEliminar.Size = new System.Drawing.Size(131, 29);
            this.btnEliminar.TabIndex = 10;
            this.btnEliminar.Text = "Eliminar";
            this.btnEliminar.UseVisualStyleBackColor = false;
            this.btnEliminar.Click += new System.EventHandler(this.btnEliminar_Click);
            // 
            // txtWea
            // 
            this.txtWea.AutoSize = true;
            this.txtWea.BackColor = System.Drawing.Color.Transparent;
            this.txtWea.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtWea.ForeColor = System.Drawing.Color.White;
            this.txtWea.Location = new System.Drawing.Point(60, 36);
            this.txtWea.Name = "txtWea";
            this.txtWea.Size = new System.Drawing.Size(0, 16);
            this.txtWea.TabIndex = 42;
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(849, 61);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(143, 16);
            this.label2.TabIndex = 0;
            this.label2.Text = "AGREGAR ELEMENTO";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.Transparent;
            this.label12.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(22, 61);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(44, 16);
            this.label12.TabIndex = 52;
            this.label12.Text = "AROS";
            // 
            // label13
            // 
            this.label13.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.Transparent;
            this.label13.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(22, 277);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(85, 16);
            this.label13.TabIndex = 53;
            this.label13.Text = "BASTIDORES";
            // 
            // label14
            // 
            this.label14.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.Transparent;
            this.label14.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.White;
            this.label14.Location = new System.Drawing.Point(22, 498);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(93, 16);
            this.label14.TabIndex = 54;
            this.label14.Text = "ACCESORIOS";
            // 
            // aROSTableAdapter3
            // 
            this.aROSTableAdapter3.ClearBeforeFill = true;
            // 
            // label15
            // 
            this.label15.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.Transparent;
            this.label15.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.White;
            this.label15.Location = new System.Drawing.Point(45, 19);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(79, 25);
            this.label15.TabIndex = 55;
            this.label15.Text = "STOCK";
            // 
            // Stock
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(66)))), ((int)(((byte)(82)))));
            this.ClientSize = new System.Drawing.Size(1480, 715);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.dataGridView3);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.label2);
            this.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.Black;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Stock";
            this.Text = "Stock";
            this.Load += new System.EventHandler(this.Stock_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.aROSBindingSource3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bdElCofreDelBordadoDataSet14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.aROSBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bdElCofreDelBordadoDataSet11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.aROSBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bdElCofreDelBordadoDataSet6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bdElCofreDelBordadoDataSet3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.aROSBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bASTIDORESBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bdElCofreDelBordadoDataSet10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bASTIDORESBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bdElCofreDelBordadoDataSet4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.aCCESORIOSBindingSource3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bdElCofreDelBordadoDataSet9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.aCCESORIOSBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bdElCofreDelBordadoDataSet8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.aCCESORIOSBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bdElCofreDelBordadoDataSet5)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bdElCofreDelBordadoDataSet7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.aCCESORIOSBindingSource1)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.DataGridView dataGridView1;
        private BdElCofreDelBordadoDataSet3 bdElCofreDelBordadoDataSet3;
        private System.Windows.Forms.BindingSource aROSBindingSource;
        private BdElCofreDelBordadoDataSet3TableAdapters.AROSTableAdapter aROSTableAdapter;
        private System.Windows.Forms.DataGridView dataGridView2;
        private BdElCofreDelBordadoDataSet4 bdElCofreDelBordadoDataSet4;
        private System.Windows.Forms.BindingSource bASTIDORESBindingSource;
        private BdElCofreDelBordadoDataSet4TableAdapters.BASTIDORESTableAdapter bASTIDORESTableAdapter;
        private System.Windows.Forms.DataGridView dataGridView3;
        private BdElCofreDelBordadoDataSet5 bdElCofreDelBordadoDataSet5;
        private System.Windows.Forms.BindingSource aCCESORIOSBindingSource;
        private BdElCofreDelBordadoDataSet5TableAdapters.ACCESORIOSTableAdapter aCCESORIOSTableAdapter;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtBuscar;
        private BdElCofreDelBordadoDataSet6 bdElCofreDelBordadoDataSet6;
        private System.Windows.Forms.BindingSource aROSBindingSource1;
        private BdElCofreDelBordadoDataSet6TableAdapters.AROSTableAdapter aROSTableAdapter1;
        private BdElCofreDelBordadoDataSet7 bdElCofreDelBordadoDataSet7;
        private System.Windows.Forms.BindingSource aCCESORIOSBindingSource1;
        private BdElCofreDelBordadoDataSet7TableAdapters.ACCESORIOSTableAdapter aCCESORIOSTableAdapter1;
        private BdElCofreDelBordadoDataSet8 bdElCofreDelBordadoDataSet8;
        private System.Windows.Forms.BindingSource aCCESORIOSBindingSource2;
        private BdElCofreDelBordadoDataSet8TableAdapters.ACCESORIOSTableAdapter aCCESORIOSTableAdapter2;
        private BdElCofreDelBordadoDataSet9 bdElCofreDelBordadoDataSet9;
        private System.Windows.Forms.BindingSource aCCESORIOSBindingSource3;
        private BdElCofreDelBordadoDataSet9TableAdapters.ACCESORIOSTableAdapter aCCESORIOSTableAdapter3;
        private BdElCofreDelBordadoDataSet10 bdElCofreDelBordadoDataSet10;
        private System.Windows.Forms.BindingSource bASTIDORESBindingSource1;
        private BdElCofreDelBordadoDataSet10TableAdapters.BASTIDORESTableAdapter bASTIDORESTableAdapter1;
        private BdElCofreDelBordadoDataSet11 bdElCofreDelBordadoDataSet11;
        private System.Windows.Forms.BindingSource aROSBindingSource2;
        private BdElCofreDelBordadoDataSet11TableAdapters.AROSTableAdapter aROSTableAdapter2;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDACCESORIOSDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nOMBREDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn tIPODataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dESCRIPCIONDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pRECIODataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button btnEliminar;
        private System.Windows.Forms.Label txtWea;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox txtTipo;
        private System.Windows.Forms.TextBox txtPrecio;
        private System.Windows.Forms.TextBox txtStock;
        private System.Windows.Forms.TextBox txtDescripcion;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtNombre;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private BdElCofreDelBordadoDataSet14 bdElCofreDelBordadoDataSet14;
        private System.Windows.Forms.BindingSource aROSBindingSource3;
        private BdElCofreDelBordadoDataSet14TableAdapters.AROSTableAdapter aROSTableAdapter3;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDAROSDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nOMBREDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dESCRIPCIÓNDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn pRECIODataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn sTOCKDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDBASTIDORDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nOMBREDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dESCRIPCIÓNDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pRECIODataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button btnRellenar;
    }
}